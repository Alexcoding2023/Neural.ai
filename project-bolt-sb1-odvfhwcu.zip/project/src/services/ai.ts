import { HfInference } from '@huggingface/inference';

const API_KEY = "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";

const inference = new HfInference(API_KEY);

// Helper function to get a random delay within a range
function getRandomDelay(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

// Helper function to determine if we should add a longer pause
function shouldPause(text: string): boolean {
  const punctuation = ['.', '!', '?', ':', ';'];
  return punctuation.some(p => text.endsWith(p));
}

export async function* streamResponse(text: string): AsyncGenerator<string> {
  const response = await inference.textGeneration({
    model: "mistralai/Mistral-7B-Instruct-v0.2",
    inputs: `<s>[INST] ${text} [/INST]`,
    parameters: {
      max_new_tokens: 500,
      temperature: 0.7,
      top_p: 0.95,
      repetition_penalty: 1.15,
      return_full_text: false
    }
  });

  const fullText = response.generated_text?.trim() || "I apologize, but I couldn't generate a proper response.";
  let currentText = '';
  
  // Stream character by character with natural pauses
  for (let i = 0; i < fullText.length; i++) {
    currentText += fullText[i];
    yield currentText;

    // Add natural delays with faster timing
    if (fullText[i] === ' ') {
      // Shorter pause between words
      await new Promise(resolve => setTimeout(resolve, getRandomDelay(30, 50)));
    } else if (shouldPause(currentText)) {
      // Shorter pause after punctuation
      await new Promise(resolve => setTimeout(resolve, getRandomDelay(100, 200)));
    } else {
      // Minimal delay between characters
      await new Promise(resolve => setTimeout(resolve, getRandomDelay(10, 20)));
    }
  }
}