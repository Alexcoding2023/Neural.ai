import React, { useState, useEffect, useRef } from 'react';
import { Message, Chat } from './types';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { TypingIndicator } from './components/TypingIndicator';
import { SettingsModal } from './components/SettingsModal';
import { Sun, Moon, Settings, Trash2, Plus, Bot, MessageSquare, Edit2, Check, X } from 'lucide-react';
import { streamResponse } from './services/ai';

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('darkMode');
    return saved ? JSON.parse(saved) : false;
  });
  const [currentChat, setCurrentChat] = useState<string>('New Chat');
  const [chats, setChats] = useState<Chat[]>(() => {
    const saved = localStorage.getItem('chats');
    return saved ? JSON.parse(saved) : [];
  });
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const editInputRef = useRef<HTMLInputElement>(null);

  // Initialize first chat if none exists
  useEffect(() => {
    if (chats.length === 0) {
      startNewChat();
    } else {
      setActiveChat(chats[0].id);
    }
  }, []);

  // Focus edit input when editing starts
  useEffect(() => {
    if (editingChatId && editInputRef.current) {
      editInputRef.current.focus();
    }
  }, [editingChatId]);

  // Load messages for active chat
  useEffect(() => {
    if (activeChat) {
      const chat = chats.find(c => c.id === activeChat);
      if (chat) {
        setMessages(chat.messages);
        setCurrentChat(chat.title);
      }
    }
  }, [activeChat, chats]);

  // Save chats to localStorage
  useEffect(() => {
    localStorage.setItem('chats', JSON.stringify(chats));
  }, [chats]);

  // Save dark mode preference
  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (content: string) => {
    // If no active chat, create one
    if (!activeChat) {
      startNewChat();
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      sender: 'user',
      timestamp: new Date(),
    };
    
    const updatedMessages = [...messages, userMessage];
    setMessages(updatedMessages);
    updateChat(updatedMessages);

    const botMessageId = (Date.now() + 1).toString();
    const botMessage: Message = {
      id: botMessageId,
      content: '',
      sender: 'bot',
      timestamp: new Date(),
      read: true,
    };
    
    const messagesWithBot = [...updatedMessages, botMessage];
    setMessages(messagesWithBot);
    setIsTyping(true);

    try {
      let finalContent = '';
      for await (const chunk of streamResponse(content)) {
        finalContent = chunk;
        setMessages(prev => {
          const updated = prev.map(msg => 
            msg.id === botMessageId 
              ? { ...msg, content: chunk }
              : msg
          );
          return updated;
        });
      }
      
      // Update chat with final content
      const finalMessages = [...updatedMessages, { ...botMessage, content: finalContent }];
      updateChat(finalMessages);
      
    } catch (error) {
      console.error('Error in handleSendMessage:', error);
      const errorMessage = "I apologize, but I'm having trouble responding right now. Please try again later.";
      setMessages(prev => {
        const updated = prev.map(msg => 
          msg.id === botMessageId 
            ? { ...msg, content: errorMessage }
            : msg
        );
        updateChat(updated);
        return updated;
      });
    } finally {
      setIsTyping(false);
    }
  };

  const updateChat = (updatedMessages: Message[]) => {
    if (activeChat) {
      setChats(prev => prev.map(chat => 
        chat.id === activeChat 
          ? { ...chat, messages: updatedMessages }
          : chat
      ));
    }
  };

  const deleteChat = (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (chatId === activeChat) {
      const remainingChats = chats.filter(c => c.id !== chatId);
      setChats(remainingChats);
      if (remainingChats.length > 0) {
        setActiveChat(remainingChats[0].id);
      } else {
        startNewChat();
      }
    } else {
      setChats(prev => prev.filter(c => c.id !== chatId));
    }
  };

  const startEditingChat = (chatId: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingChatId(chatId);
    setEditingTitle(currentTitle);
  };

  const saveEditedTitle = (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (editingTitle.trim()) {
      setChats(prev => prev.map(chat =>
        chat.id === chatId
          ? { ...chat, title: editingTitle.trim() }
          : chat
      ));
    }
    setEditingChatId(null);
    setEditingTitle('');
  };

  const cancelEditing = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingChatId(null);
    setEditingTitle('');
  };

  const clearChat = () => {
    if (activeChat) {
      setChats(prev => prev.filter(chat => chat.id !== activeChat));
    }
    setMessages([]);
    startNewChat();
  };

  const startNewChat = () => {
    const newChatId = Date.now().toString();
    const welcomeMessage: Message = {
      id: '1',
      content: "Hello! I'm Mohammed, an AI assistant. How can I help you today?",
      sender: 'bot',
      timestamp: new Date(),
      read: true,
    };

    const newChat: Chat = {
      id: newChatId,
      title: 'New Chat',
      messages: [welcomeMessage],
      timestamp: new Date(),
    };

    setChats(prev => [...prev, newChat]);
    setActiveChat(newChatId);
    setMessages([welcomeMessage]);
    setCurrentChat('New Chat');
  };

  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  return (
    <div className={`h-screen flex ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      {/* Sidebar */}
      <div className={`w-72 flex flex-col ${isDarkMode ? 'bg-gray-800' : 'bg-white'} border-r ${isDarkMode ? 'border-gray-700' : 'border-gray-200'} shadow-lg`}>
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <button
            onClick={startNewChat}
            className={`w-full p-3 flex items-center justify-center gap-2 rounded-lg transition-all duration-200 ${
              isDarkMode 
                ? 'bg-green-600 text-white hover:bg-green-700' 
                : 'bg-green-600 text-white hover:bg-green-700'
            }`}
          >
            <Plus size={18} />
            New Chat
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {chats.map(chat => (
            <div
              key={chat.id}
              onClick={() => setActiveChat(chat.id)}
              className={`group flex items-center gap-2 p-3 rounded-lg transition-all duration-200 cursor-pointer ${
                activeChat === chat.id
                  ? (isDarkMode ? 'bg-gray-700 text-white' : 'bg-gray-200 text-gray-900')
                  : (isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100')
              }`}
            >
              <MessageSquare size={16} className="flex-shrink-0" />
              {editingChatId === chat.id ? (
                <div className="flex-1 flex items-center gap-1" onClick={e => e.stopPropagation()}>
                  <input
                    ref={editInputRef}
                    type="text"
                    value={editingTitle}
                    onChange={(e) => setEditingTitle(e.target.value)}
                    className={`flex-1 px-2 py-1 rounded text-sm ${
                      isDarkMode 
                        ? 'bg-gray-600 text-white' 
                        : 'bg-white text-gray-900'
                    }`}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        saveEditedTitle(chat.id, e as any);
                      } else if (e.key === 'Escape') {
                        cancelEditing(e as any);
                      }
                    }}
                  />
                  <button
                    onClick={(e) => saveEditedTitle(chat.id, e)}
                    className="p-1 text-green-500 hover:text-green-400"
                  >
                    <Check size={14} />
                  </button>
                  <button
                    onClick={cancelEditing}
                    className="p-1 text-red-500 hover:text-red-400"
                  >
                    <X size={14} />
                  </button>
                </div>
              ) : (
                <>
                  <span className="flex-1 truncate text-sm">{chat.title}</span>
                  <div className={`opacity-0 group-hover:opacity-100 flex items-center gap-1 ${
                    isDarkMode ? 'text-gray-400' : 'text-gray-500'
                  }`}>
                    <button
                      onClick={(e) => startEditingChat(chat.id, chat.title, e)}
                      className="p-1 hover:text-blue-500 transition-colors"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button
                      onClick={(e) => deleteChat(chat.id, e)}
                      className="p-1 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
        
        <div className={`p-4 border-t ${isDarkMode ? 'border-gray-700' : 'border-gray-200'}`}>
          <button
            onClick={toggleDarkMode}
            className={`w-full p-3 flex items-center gap-2 rounded-lg transition-all duration-200 ${
              isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            {isDarkMode ? <Moon size={18} /> : <Sun size={18} />}
            {isDarkMode ? 'Dark Mode' : 'Light Mode'}
          </button>
          <button
            onClick={() => setIsSettingsOpen(true)}
            className={`w-full p-3 flex items-center gap-2 rounded-lg transition-all duration-200 ${
              isDarkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Settings size={18} />
            Settings
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col max-w-5xl mx-auto w-full">
        {/* Chat Header */}
        <div className={`flex items-center justify-between p-4 border-b ${
          isDarkMode ? 'bg-gray-800 border-gray-700 text-white' : 'bg-white border-gray-200'
        } shadow-sm`}>
          <div className="flex items-center gap-3">
            <Bot size={20} className="text-green-600" />
            <h1 className="text-lg font-semibold">Chat with Mohammed</h1>
          </div>
          <button
            onClick={clearChat}
            className={`p-2 rounded-lg transition-all duration-200 ${
              isDarkMode 
                ? 'text-gray-400 hover:bg-gray-700 hover:text-gray-200' 
                : 'text-gray-500 hover:bg-gray-100 hover:text-gray-700'
            }`}
          >
            <Trash2 size={20} />
          </button>
        </div>

        {/* Messages */}
        <div className={`flex-1 overflow-y-auto ${isDarkMode ? 'bg-gray-900' : 'bg-gray-50'}`}>
          <div className="max-w-3xl mx-auto p-4 space-y-6">
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} isDarkMode={isDarkMode} />
            ))}
            {isTyping && (
              <div className="flex items-center gap-2 mb-4 animate-fade-in">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  isDarkMode ? 'bg-gray-800' : 'bg-white'
                } shadow-sm`}>
                  <Bot size={16} className="text-green-600" />
                </div>
                <TypingIndicator isDarkMode={isDarkMode} />
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Input */}
        <div className={`border-t ${isDarkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'} shadow-lg`}>
          <ChatInput onSendMessage={handleSendMessage} isDarkMode={isDarkMode} />
        </div>
      </div>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
      />
    </div>
  );
}

export default App;