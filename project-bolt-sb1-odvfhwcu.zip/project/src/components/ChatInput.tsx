import React, { useState, useRef } from 'react';
import { Send } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isDarkMode: boolean;
}

export function ChatInput({ onSendMessage, isDarkMode }: ChatInputProps) {
  const [message, setMessage] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message);
      setMessage('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  };

  return (
    <div className={`p-4 ${isDarkMode ? 'bg-gray-800' : 'bg-white'}`}>
      <form onSubmit={handleSubmit} className="max-w-3xl mx-auto">
        <div className={`relative flex items-end rounded-xl border ${
          isDarkMode ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-300'
        } shadow-sm transition-all duration-200 focus-within:border-green-500 focus-within:ring-1 focus-within:ring-green-500`}>
          <textarea
            ref={textareaRef}
            value={message}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder="Send a message..."
            rows={1}
            className={`flex-1 p-3 pr-12 max-h-48 rounded-xl resize-none focus:outline-none transition-colors duration-200 ${
              isDarkMode ? 'bg-gray-700 text-white placeholder-gray-400' : 'bg-white text-gray-900 placeholder-gray-500'
            }`}
          />
          <button
            type="submit"
            className={`absolute right-2 bottom-2 p-2 rounded-lg transition-all duration-200 ${
              message.trim() 
                ? 'bg-green-600 text-white hover:bg-green-700' 
                : (isDarkMode ? 'bg-gray-600 text-gray-400' : 'bg-gray-100 text-gray-400')
            }`}
            disabled={!message.trim()}
          >
            <Send size={20} />
          </button>
        </div>
        <p className={`mt-2 text-xs text-center ${isDarkMode ? 'text-gray-400' : 'text-gray-500'}`}>
          Press Enter to send, Shift + Enter for new line
        </p>
      </form>
    </div>
  );
}