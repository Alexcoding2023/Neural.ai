import React from 'react';

interface TypingIndicatorProps {
  isDarkMode: boolean;
}

export function TypingIndicator({ isDarkMode }: TypingIndicatorProps) {
  return (
    <div className={`flex items-center space-x-1 px-4 py-2 rounded-full ${
      isDarkMode ? 'bg-gray-800' : 'bg-white'
    } shadow-sm w-16`}>
      <div className={`w-2 h-2 ${isDarkMode ? 'bg-green-500' : 'bg-green-500'} rounded-full animate-bounce opacity-75`} style={{ animationDelay: '0ms' }} />
      <div className={`w-2 h-2 ${isDarkMode ? 'bg-green-500' : 'bg-green-500'} rounded-full animate-bounce opacity-75`} style={{ animationDelay: '150ms' }} />
      <div className={`w-2 h-2 ${isDarkMode ? 'bg-green-500' : 'bg-green-500'} rounded-full animate-bounce opacity-75`} style={{ animationDelay: '300ms' }} />
    </div>
  );
}