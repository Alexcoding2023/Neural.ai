import React from 'react';
import { Message } from '../types';
import ReactMarkdown from 'react-markdown';
import { Check, Bot, User } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
  isDarkMode: boolean;
}

export function ChatMessage({ message, isDarkMode }: ChatMessageProps) {
  const isBot = message.sender === 'bot';
  
  return (
    <div className={`flex w-full mb-6 animate-fade-in ${isBot ? 'justify-start' : 'justify-end'}`}>
      <div className={`flex items-start gap-3 max-w-[80%] ${isBot ? 'flex-row' : 'flex-row-reverse'}`}>
        <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${
          isBot 
            ? (isDarkMode ? 'bg-gray-800 text-green-600' : 'bg-white text-green-600') 
            : (isDarkMode ? 'bg-gray-800 text-blue-500' : 'bg-white text-blue-500')
        }`}>
          {isBot ? <Bot size={16} /> : <User size={16} />}
        </div>
        
        <div className={`relative group ${isBot ? 'items-start' : 'items-end'}`}>
          <div className={`px-4 py-3 rounded-2xl shadow-sm transition-all duration-200 ${
            isDarkMode
              ? (isBot ? 'bg-gray-800 hover:bg-gray-750' : 'bg-blue-600 hover:bg-blue-700')
              : (isBot ? 'bg-white hover:bg-gray-50' : 'bg-blue-600 hover:bg-blue-700')
          } ${isDarkMode ? 'text-gray-100' : (isBot ? 'text-gray-800' : 'text-white')}`}>
            <ReactMarkdown 
              className="prose prose-sm max-w-none"
              components={{
                p: ({children}) => <p className="mb-2 last:mb-0">{children}</p>,
                code: ({children}) => (
                  <code className={`px-1 py-0.5 rounded ${
                    isDarkMode ? 'bg-gray-700' : 'bg-gray-100'
                  }`}>
                    {children}
                  </code>
                ),
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
          
          <div className="flex items-center gap-1 mt-1 text-xs text-gray-500">
            <span>{new Date(message.timestamp).toLocaleTimeString([], { 
              hour: '2-digit', 
              minute: '2-digit'
            })}</span>
            {!isBot && message.read && (
              <Check size={12} className="text-blue-500" />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}