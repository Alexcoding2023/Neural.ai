export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  read?: boolean;
  type?: 'text' | 'image' | 'link' | 'suggestion';
}

export interface Chat {
  id: string;
  title: string;
  messages: Message[];
  timestamp: Date;
}

export interface SuggestionButton {
  id: string;
  text: string;
  action: string;
}